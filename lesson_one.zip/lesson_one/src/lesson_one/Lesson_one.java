/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson_one;

/**
 *
 * @author student
 */
public class Lesson_one {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Dog Dog1 = new Dog ("Charlie", 3);
        Dog Dog2 = new Dog ("George", 7);
        Dog Dog3 = new Dog ("Goodboy", 1);
        Dog Dog4 = new Dog ("Luci", 3);
        
        System.out.println(Dog3.GetName());
        Dog4.SetDogDescription("She is a good girl too!");
        System.out.println(Dog4.GetDogDescription());
        System.out.println(Dog2.GetYears());
        Dog2.SetYears (Dog2.GetYears()+1);
        System.out.println(Dog2.GetYears());
        System.out.println(Dog1.CountToHumanYears());
    }
    
}
