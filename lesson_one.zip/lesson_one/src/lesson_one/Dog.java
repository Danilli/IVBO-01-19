/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson_one;

/**
 *
 * @author student
 */
public class Dog {
    private String name;
    private int years;
    private String DogDescription = "Just a dog";
    
    public Dog (String Name, int Years)
    {
        name = Name;
        years = Years;
    }
    
    public void SetName (String NewName)
    {
        name = NewName;
    }
    
    public void SetYears (int NewYears)
    {
        years = NewYears;
    }
    
    public void SetDogDescription (String NewDescription)
    {
        DogDescription = NewDescription;
    }
    
    public String GetName ()
    {
        return name;
    }
    
    public String GetDogDescription ()
    {
        return DogDescription;
    }
   
    public int GetYears ()
    {
        return years;
    }
    
    public int CountToHumanYears()
    {
        return years*7;
    }
    
    
    
}
