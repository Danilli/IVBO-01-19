/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laba1;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author student
 */
public class Laba1 {

    public static int MakeFactorial (int Chi) // Метод для пятой задачи лабораторной
    {
        int Res = 1; 
        for (int i = 2; i<=Chi; i++) //Цикл, вычисляющий факториал заданного числа
        {
            Res*=i;
        }
        return Res;
    }
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        // FIRS CHALLENGE
        
        int mas[] = new int[5]; // Инициализируем массив
        
        for (int i = 0; i<5; i++) // Заполняем массив случайными числами
        {
            mas[i] = (int)(Math.random()*12)-i*2;
        }
        
        int sum = 0;
        for (int i = 0; i<5; i++) // считаем сумму чисел в массиве циклом for
        {
            sum+=mas[i];
        } 
        System.out.println(sum); 
                
        sum = 0;
        int iter = 0;
        while (mas.length != iter) // считаем сумму чисел в массиве циклом for While
        {
            sum+= mas[iter];
            iter++;
        }
        System.out.println(sum);
        
        sum = 0;
        iter = 0;
        do // считаем сумму чисел в массиве циклом do/while
        {
            sum += mas[iter];
            iter++;
        }while (mas.length != iter);
        System.out.println(sum);
        
        //SECOND QUEST
        
        for (String arg : args) // Выводим аргументы командной строки циклом for 
        {
             System.out.println(arg);
        }
        
        //THIRD TASK
        
        String GarmonStart = "1/"; 
        System.out.print ("1 ");
        for (int i = 2; i<11; i++) { //Выводим первые 10 гармонических чисел
            System.out.print(GarmonStart + i + " ");
        }
         
        // FOURTH JOB
        
        int Array[] = new int [10]; 
        System.out.println();
                
        for (int i = 0; i<10; i++) //Заполняем массив случайными числами
        {
            Array[i] = ((int)(Math.random()*12)-i*2)*
                    ((int)(Math.random()*12)-i*2);
        }
       
        
        for (int elem : Array) // Выводим массив
        {
            System.out.print(elem + " ");
        }
        
        Arrays.sort(Array); // Сортируем массив
        System.out.println(); 
        
        for (int elem : Array) // Выводим отсортированныый массив
        {
            System.out.print(elem + " ");
        }
        System.out.println();
        
        //FIRTH MISSION
        
        Scanner sc = new Scanner(System.in); 
        int Chislo = 0;
        if (sc.hasNextInt())
        {
            Chislo = sc.nextInt(); // Пользователь вводит число
        }
        System.out.println(MakeFactorial (Chislo)); // Выводим получившийся факториал
     }  

    }
